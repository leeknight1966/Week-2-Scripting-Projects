Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>>      # Calculate an object's momentum in kg.m/s
     
>>> mass = int(input("Enter the object's mass in kilograms: "))
Enter the object's mass in kilograms: 200
>>> velocity = int(input("Enter the object's velocity in meters per second: "))
Enter the object's velocity in meters per second: 20
>>> momentum = mass * velocity
>>> print("The object's momentum in kg.m/s is", momentum)
The object's momentum in kg.m/s is 4000
>>> 