Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Calculate Surface Area of a Cube if a side is 5
>>> width = 5
>>> height = 5
>>> length = 5
>>> sa = width = height = length # sa (surface area)
>>> surfacearea = 6* (sa * sa) # surface area of cube equals 6 multiplied by (sa multiplied by 2)
>>> print("Surface Area of a Cube with a side of 5 is: ");
Surface Area of a Cube with a side of 5 is: 
>>> print(surfacearea);
150
>>> 
>>> 
>>> 
>>> width = 7.564
>>> height = 7.564
>>> length = 7.564
>>> sa = width = height = length
>>> surfacearea = 6* (sa * sa)
>>> print("Surface Area of a Cube with a side of 7.564 is: ");
Surface Area of a Cube with a side of 7.564 is: 
>>> print(surfacearea);
343.284576
>>> 