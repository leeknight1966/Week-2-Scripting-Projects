Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 		# Customer nightly charges to rent new and old videos.
		
>>> new = 3.00
>>> old = 2.00
>>> newvideo = int(input("Enter the number of new videos rented: "))
Enter the number of new videos rented: 2
>>> oldvideo = int(input("Enter the number of old videos rented: "))
Enter the number of old videos rented: 1
>>> amount = (2 + new) + (old)
>>> print ("The customer owes","$",amount)
The customer owes $ 7.0
>>> 